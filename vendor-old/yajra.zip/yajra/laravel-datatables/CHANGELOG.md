# Laravel DataTables Complete Package

## Change Log

### v1.5.0 - 2019-02-27

- Force use buttons and html package v4.

### v1.4.0 - 2018-11-02

- Force use buttons and html package v4.

### v1.3.0 - 2018-11-02

- Add support for html v4.

### v1.2.0 - 2018-11-02

- Include DataTables Editor package.

### v1.1.0 - 2018-08-16

- Add support for buttons v4.x.

### v1.0.0 - 2017-08-31

- First stable version.
